class AppSpacing {
  static const xs = 4.0;

  static const sm = 8.0;

  static const md = 16.0;

  static const lg = 24.0;

  static const xl = 32.0;

  static const xxl = 40.0;
}